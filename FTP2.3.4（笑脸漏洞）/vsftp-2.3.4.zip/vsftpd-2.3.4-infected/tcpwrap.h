#ifndef VSF_TCPWRAP_H
#define VSF_TCPWRAP_H

int vsf_tcp_wrapper_ok(int remote_fd);

#endif /* VSF_TCPWRAP_H */

